# two-fingers-gestures
An extensions for Firefox for Android
